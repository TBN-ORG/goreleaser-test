# goreleaser-test
A simple test project to test setup of goreleaser.
